package com.LibraryManagement.LibMgm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibMgmApplicationTests {

	@Test
	void contextLoads() {
	}

}
